<!-- Main Container -->
<main id="main-container">
	<!-- Page Content -->
	<div class="content">
		<div class="row">
			<div class="col-md-8">
				<div class="block block-themed">
					<div class="block-header bg-gd-sea">
						<h3 class="block-title"><span class="si si-info"></span> Informasi</h3>
					</div>
					<div class="block-content">
						<p><h3>Selamat Datang</h3></p>
						<p>SARTONO atau SMART TRASH MONITORING adalah sebuah sistem ..................</p>
					</div>
				</div>
			</div>
			
			<div class="col-md-4">
				<div class="block block-themed">
					<div class="block-header bg-gd-sea">
						<h3 class="block-title"><span class="si si-info"></span> Informasi Akun</h3>
					</div>
					<div class="block-content">
						<p>Block’s content..</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="block block-themed">
					<div class="block-header bg-gd-sea">
						<h3 class="block-title"><span class="si si-info"></span> Terupdate</h3>
					</div>
					<div class="block-content">
						<div id="map"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- END Page Content -->
</main>
<!-- END Main Container -->
<script src="<?=base_url();?>assets/js/core/jquery.min.js"></script>
<script type="text/javascript">
$(function() {
  var url="<?=base_url('data_ketinggian/getlokasi')?>";

        $.ajax(
          {
            type: "GET",
            url: url,
          }
        ).done(function( data )
        {
          var jsonObj = JSON.parse(data);
          var count = Object.keys(jsonObj).length;
          setTimeout(function () {
              for (var i = 0; i < count; i++) {
               var lat_lng = new google.maps.LatLng(jsonObj[i].lt,jsonObj[i].lg);
               var nama =jsonObj[i].lokasi;
               var a = i+1;
               var sContent = '<h4>'+jsonObj[i].lokasi+'</h4>';
                  addMarker(nama,lat_lng,sContent,a*200,08776868);
              }
          }, 3000);
        });
})

//Set up some of our variables.
var map; //Will contain map object.
var marker = false; ////Has the user plotted their location marker?
var markers = [];
//Function called to initialize / create the map.
//This is called when the page has loaded.
function initMap() {
  var time_now = new Date().getHours();

        var style_map;
        if (time_now >= 6 && time_now < 18){
            style_map=[
                {elementType: 'geometry', stylers: [{color: '#ebe3cd'}]},
                {elementType: 'labels.text.fill', stylers: [{color: '#523735'}]},
                {elementType: 'labels.text.stroke', stylers: [{color: '#f5f1e6'}]},
                {
                    featureType: 'administrative',
                    elementType: 'geometry.stroke',
                    stylers: [{color: '#c9b2a6'}]
                },
                {
                    featureType: 'administrative.land_parcel',
                    elementType: 'geometry.stroke',
                    stylers: [{color: '#dcd2be'}]
                },
                {
                    featureType: 'administrative.land_parcel',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#ae9e90'}]
                },
                {
                    featureType: 'landscape.natural',
                    elementType: 'geometry',
                    stylers: [{color: '#dfd2ae'}]
                },
                {
                    featureType: 'poi',
                    elementType: 'geometry',
                    stylers: [{color: '#dfd2ae'}]
                },
                {
                    featureType: 'poi',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#93817c'}]
                },
                {
                    featureType: 'poi.park',
                    elementType: 'geometry.fill',
                    stylers: [{color: '#a5b076'}]
                },
                {
                    featureType: 'poi.park',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#447530'}]
                },
                {
                    featureType: 'road',
                    elementType: 'geometry',
                    stylers: [{color: '#f5f1e6'}]
                },
                {
                    featureType: 'road.arterial',
                    elementType: 'geometry',
                    stylers: [{color: '#fdfcf8'}]
                },
                {
                    featureType: 'road.highway',
                    elementType: 'geometry',
                    stylers: [{color: '#f8c967'}]
                },
                {
                    featureType: 'road.highway',
                    elementType: 'geometry.stroke',
                    stylers: [{color: '#e9bc62'}]
                },
                {
                    featureType: 'road.highway.controlled_access',
                    elementType: 'geometry',
                    stylers: [{color: '#e98d58'}]
                },
                {
                    featureType: 'road.highway.controlled_access',
                    elementType: 'geometry.stroke',
                    stylers: [{color: '#db8555'}]
                },
                {
                    featureType: 'road.local',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#806b63'}]
                },
                {
                    featureType: 'transit.line',
                    elementType: 'geometry',
                    stylers: [{color: '#dfd2ae'}]
                },
                {
                    featureType: 'transit.line',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#8f7d77'}]
                },
                {
                    featureType: 'transit.line',
                    elementType: 'labels.text.stroke',
                    stylers: [{color: '#ebe3cd'}]
                },
                {
                    featureType: 'transit.station',
                    elementType: 'geometry',
                    stylers: [{color: '#dfd2ae'}]
                },
                {
                    featureType: 'water',
                    elementType: 'geometry.fill',
                    stylers: [{color: '#b9d3c2'}]
                },
                {
                    featureType: 'water',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#92998d'}]
                }
            ];
        } else {
            style_map=[
                {elementType: 'geometry', stylers: [{color: '#242f3e'}]},
                {elementType: 'labels.text.stroke', stylers: [{color: '#242f3e'}]},
                {elementType: 'labels.text.fill', stylers: [{color: '#746855'}]},
                {
                    featureType: 'administrative.locality',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#d59563'}]
                },
                {
                    featureType: 'poi',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#d59563'}]
                },
                {
                    featureType: 'poi.park',
                    elementType: 'geometry',
                    stylers: [{color: '#263c3f'}]
                },
                {
                    featureType: 'poi.park',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#6b9a76'}]
                },
                {
                    featureType: 'road',
                    elementType: 'geometry',
                    stylers: [{color: '#38414e'}]
                },
                {
                    featureType: 'road',
                    elementType: 'geometry.stroke',
                    stylers: [{color: '#212a37'}]
                },
                {
                    featureType: 'road',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#9ca5b3'}]
                },
                {
                    featureType: 'road.highway',
                    elementType: 'geometry',
                    stylers: [{color: '#746855'}]
                },
                {
                    featureType: 'road.highway',
                    elementType: 'geometry.stroke',
                    stylers: [{color: '#1f2835'}]
                },
                {
                    featureType: 'road.highway',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#f3d19c'}]
                },
                {
                    featureType: 'transit',
                    elementType: 'geometry',
                    stylers: [{color: '#2f3948'}]
                },
                {
                    featureType: 'transit.station',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#d59563'}]
                },
                {
                    featureType: 'water',
                    elementType: 'geometry',
                    stylers: [{color: '#17263c'}]
                },
                {
                    featureType: 'water',
                    elementType: 'labels.text.fill',
                    stylers: [{color: '#515c6d'}]
                },
                {
                    featureType: 'water',
                    elementType: 'labels.text.stroke',
                    stylers: [{color: '#17263c'}]
                }
            ];
        }


    //The center location of our map.
    var centerOfMap = new google.maps.LatLng(-7.6909648, 109.0193167);

    //Map options.
    var options = {
      center: centerOfMap, //Set center.
      zoom: 12,
      disableDefaultUI: true, //The zoom value.
      zoomControlOptions: { position: google.maps.ControlPosition.LEFT_CENTER },
      fullscreenControlOptions: { position: google.maps.ControlPosition.LEFT_TOP },
      styles: style_map

    };
    //Create the map object.
    map = new google.maps.Map(document.getElementById('map'), options);
    console.log(map);

}


//Load the map when the page has finished loading.
google.maps.event.addDomListener(window, 'load', initMap);

// Adds a marker to the map and push to the array.
function addMarker(nm,location,sContent, timeout,nohp) {

console.log(location);
  var image = "http://66.42.57.140/air_monitoring/assets/img/icon.png";
  var marker = new google.maps.Marker({
    position: location,
    map: map,
    icon:image,
    info:sContent,
    visible: true,
    title: nm,
    animation: google.maps.Animation.DROP
  });

  window.setTimeout(function() {
  markers.push(marker);
  }, timeout);

  var infowindow = new google.maps.InfoWindow({
          content: sContent
  });

  marker.addListener('click', function() {
          infowindow.open(map, marker);
          check(nohp,nm);
        });
// marker.setMap(map);
}


</script>
