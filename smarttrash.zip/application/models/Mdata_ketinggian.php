<?php

class Mdata_ketinggian extends CI_Model {
	function getdata(){
		$query = $this->db->select('*');
		$query = $this->db->from('data_ketinggian');
		$query = $this->db->join('tb_lokasi', 'tb_lokasi.id = data_ketinggian.id_sensor');
		$query = $query = $this->db->get();
		return $query;
	}
}

?>