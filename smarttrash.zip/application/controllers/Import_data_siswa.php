<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Import_data_siswa extends CI_Controller {
	
	function __construct()
	{
		date_default_timezone_set('Asia/Jakarta');
		parent::__construct();
		
		if(!$this->session->userdata('logged_in')){
			redirect(base_url('Main_user'),'refresh');
	    }	
	}
	
	private function _render_page($view, $data = null)
	{		
		$this->viewdata = (empty($data)) ? $this->data : $data;

		$this->load->view('sekolah/_global/header',$this->viewdata);
		$this->load->view($view, $this->viewdata);
		$this->load->view('sekolah/_global/footer',$this->viewdata);
	}
	
	public function index()
	{
		$data=array(
			'menu'=>'import_data_siswa'
		);
		$this->_render_page('sekolah/import_data_siswa',$data);
	}
	
	public function import_peserta(){
		$this->load->library('PHPExcel');
		$random = "file_upload_".rand(11111,99999);
		$target_file = 'uploads/'.$random.basename($_FILES["file_excel"]["name"]);
		$uploadOk = 1;

		if (move_uploaded_file($_FILES["file_excel"]["tmp_name"], $target_file)) {

			ini_set('memory_limit', '-1');
			$objReader = PHPExcel_IOFactory::createReader('Excel2007');

			$inputFileType = 'Excel2007';
			$sheetIndex = 0;
			$inputFileName = $target_file;

			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$sheetnames = $objReader->listWorksheetNames($inputFileName);
			$objReader->setLoadSheetsOnly($sheetnames[$sheetIndex]);
			
			try {
			$objPHPExcel = $objReader->load($inputFileName);
			} catch(Exception $e) {
			die('Error loading file :' . $e->getMessage());
			}

			$worksheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
			$numRows = count($worksheet);

			//baca untuk setiap baris excel
			for ($i=1; $i <= $numRows ; $i++) {
				
				$sql = $this->db->query("INSERT INTO tb_peserta (username,nama,kelas,jk,tmt_lahir,tgl_lahir,nama_ortu,nisn,no_induk,id_sekolah,last_update)
					VALUES (
						'".$worksheet[$i]['A']."',
						'".$worksheet[$i]['B']."',
						'".$worksheet[$i]['C']."',
						'".$worksheet[$i]['D']."',
						'".$worksheet[$i]['E']."',
						'".$worksheet[$i]['F']."',
						'".$worksheet[$i]['G']."',
						'".$worksheet[$i]['H']."',
						'".$worksheet[$i]['I']."',
						'".$this->session->userdata('id_sekolah')."','".date("Y-m-d h:i:s")."')");
			
				//$insert=$this->db->insert('tb_peserta',$worksheet[$i]['A']);

				if ($sql) {
					$pesan= "Sukses Simpan Data!";

				} else {
					$pesan= "Error: Gagal <br>";
				}

			}

			 unlink($target_file);


			$pesan ='Import Excel Success!';
			echo json_encode(array('st'=>1,'pesan'=>$pesan));
		} else {
			$pesan="Sorry, there was an error uploading your file.";
			echo json_encode(array('st'=>0,'pesan'=>$pesan));
		}
	}
	
	function get_random_password($chars_min=6, $chars_max=8, $use_upper_case=false, $include_numbers=false, $include_special_chars=false)
    {
        $length = rand($chars_min, $chars_max);
        $selection = 'aeuoyibcdfghjklmnpqrstvwxz';
        if($include_numbers) {
            $selection .= "1234567890";
        }
        if($include_special_chars) {
            $selection .= "!@\"#$%&[]{}?|";
        }
                                
        $password = "";
        for($i=0; $i<$length; $i++) {
            $current_letter = $use_upper_case ? (rand(0,1) ? strtoupper($selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))];            
            $password .=  $current_letter;
        }                
        
      return $password;
    }
}
