<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_ketinggian extends CI_Controller {
	
	function __construct()
	{
		date_default_timezone_set('Asia/Jakarta');
		parent::__construct();
		
		$this->load->model('mdata_ketinggian');
		
		if(!$this->session->userdata('logged_in')){
			redirect(base_url('Auth'),'refresh');
	    }	
	}
	
	private function _render_page($view, $data = null)
	{		
		$this->viewdata = (empty($data)) ? $this->data : $data;

		$this->load->view('petugas/_global/header',$this->viewdata);
		$this->load->view($view, $this->viewdata);
		$this->load->view('petugas/_global/footer',$this->viewdata);
	}
	
	public function index()
	{
		$data=array(
			'menu'=>'data_ketinggain',
			'data_realtime'=>$this->mdata_ketinggian->getdata()->result_array()
		);
		$this->_render_page('petugas/data_realtime',$data);
	}
	
	public function getLokasi()
	{
		echo json_encode($this->db->get('tb_lokasi')->result_array());
	
	}
}
