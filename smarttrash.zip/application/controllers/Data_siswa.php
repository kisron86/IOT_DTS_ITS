<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_siswa extends CI_Controller {
	
	function __construct()
	{
		date_default_timezone_set('Asia/Jakarta');
		parent::__construct();
		
		$this->load->model('Data_peserta','dp');
		
		if(!$this->session->userdata('logged_in')){
			redirect(base_url('Main_user'),'refresh');
	    }	
	}
	
	private function _render_page($view, $data = null)
	{		
		$this->viewdata = (empty($data)) ? $this->data : $data;

		$this->load->view('sekolah/_global/header',$this->viewdata);
		$this->load->view($view, $this->viewdata);
		$this->load->view('sekolah/_global/footer',$this->viewdata);
	}
	
	public function index()
	{
		$id_sekolah=$this->session->userdata('id_sekolah');
		$peserta=$this->dp->cekdata(array('id_sekolah'=>$id_sekolah))->result_array();
		$pass=$this->get_random_password();
		$data=array(
			'menu'=>'data_siswa',
			'peserta' => $peserta,
			'pass'=>$pass
		);
		$this->_render_page('sekolah/data_siswa',$data);
	}
	
	function get_random_password($chars_min=6, $chars_max=6, $use_upper_case=false, $include_numbers=true, $include_special_chars=false)
    {
        $length = rand($chars_min, $chars_max);
        $selection = 'aeuoyibcdfghjklmnpqrstvwxz';
        if($include_numbers) {
            $selection .= "1234567890";
        }
        if($include_special_chars) {
            $selection .= "!@\"#$%&[]{}?|";
        }
                                
        $password = "";
        for($i=0; $i<$length; $i++) {
            $current_letter = $use_upper_case ? (rand(0,1) ? strtoupper($selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))];            
            $password .=  $current_letter;
        }                
        
      return $password;
    }
}
