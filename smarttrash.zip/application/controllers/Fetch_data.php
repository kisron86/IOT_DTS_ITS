<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Fetch_data extends CI_Controller{

    function __construct() {
        parent::__construct();
	}
		
    function index(){
       $data['datakontak'] = json_decode($this->curl->simple_get($this->API.'/mutasi?outlet=002'));
       $this->load->view('listmutasi',$data);
    }
    
}
?>
